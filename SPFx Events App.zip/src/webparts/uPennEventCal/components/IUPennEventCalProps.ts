export interface IUPennEventCalProps {

  title:string;
  jsonUrl:string;
  maxEvents:string;
}
