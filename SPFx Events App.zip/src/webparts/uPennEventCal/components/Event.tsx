import * as React from 'react';
import { useState, useEffect } from 'react';
//import styles from './UPennEventCal.module.scss';
import { Card, CardMedia, CardContent, Typography, Grid, Box } from '@mui/material';
import { IUPennEventCalProps } from './IUPennEventCalProps';
//import FullCalendar from '@fullcalendar/react';
//import dayGridPlugin from '@fullcalendar/daygrid';

interface IEvent {
    id:string;
    title: string;
    date: string;
    description: string;
    start_date: string;
    end_date: string;
    image: {
        url:string
    }
    location: string;
}

const EventCalendar: React.FC<IUPennEventCalProps> = ({ title, jsonUrl, maxEvents }) => {
  const [events, setEvents] = useState<IEvent[]>([]);

  useEffect(() => {
    if (jsonUrl) {
      fetch(jsonUrl)
        .then(response => response.json())
        .then(data => setEvents(data.slice(0, maxEvents))) // Limit events based on maxEvents
        .catch(error => console.error("Error fetching events:", error));
    }
  }, [jsonUrl, maxEvents]);


  return (
    <Box sx={{ padding: '20px', maxWidth: '900px', margin: '0 auto' }}>
    <Typography variant="h4" component="h2" sx={{ textAlign: 'center', marginBottom: '30px' }}>
      Upcoming Events
    </Typography>
    <Grid container spacing={3}>
      {events.map(event => (
        <Grid item xs={12} sm={6} md={4} key={event.id}>
          <Card sx={{ height: '100%', transition: 'transform 0.3s', '&:hover': { transform: 'translateY(-5px)' } }}>
            <CardMedia
              component="img"
              height="180"
              image={event.image.url}
              alt={event.image.url}
              sx={{ borderTopLeftRadius: '8px', borderTopRightRadius: '8px' }}
            />
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                <Box
                  sx={{
                    backgroundColor: '#0078d4',
                    color: '#fff',
                    padding: '8px 12px',
                    borderRadius: '4px',
                    fontSize: '1em',
                    fontWeight: 'bold',
                  }}
                >
                  {new Date(event.start_date).toLocaleDateString()}
                </Box>
                <Typography variant="body2" color="textSecondary">
                  {new Date(event.start_date).toLocaleTimeString()}
                </Typography>
              </Box>
              <Typography variant="h6" component="div" sx={{ fontWeight: 'bold', marginBottom: '8px' }}>
                {event.title}
              </Typography>
              <Typography variant="body2" color="textSecondary" sx={{ marginBottom: '8px' }}>
                {event.location}
              </Typography>
            
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  </Box>  );
};

export default EventCalendar;
