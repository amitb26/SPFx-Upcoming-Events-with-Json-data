
require("./UPennEventCal.module.css");
const styles = {
  'upcoming-events-container': 'upcoming-events-container_fbd8f9e9',
  'events-title': 'events-title_fbd8f9e9',
  'events-list': 'events-list_fbd8f9e9',
  'event-card': 'event-card_fbd8f9e9',
  'event-date': 'event-date_fbd8f9e9',
  'event-day': 'event-day_fbd8f9e9',
  'event-month': 'event-month_fbd8f9e9',
  'event-details': 'event-details_fbd8f9e9',
  'event-image': 'event-image_fbd8f9e9',
  'event-info': 'event-info_fbd8f9e9',
  'event-title': 'event-title_fbd8f9e9',
  'event-location': 'event-location_fbd8f9e9',
  'event-description': 'event-description_fbd8f9e9',
  'event-dates': 'event-dates_fbd8f9e9',
  uPennEventCal: 'uPennEventCal_fbd8f9e9',
  teams: 'teams_fbd8f9e9',
  welcome: 'welcome_fbd8f9e9',
  welcomeImage: 'welcomeImage_fbd8f9e9',
  links: 'links_fbd8f9e9'
};

export default styles;
