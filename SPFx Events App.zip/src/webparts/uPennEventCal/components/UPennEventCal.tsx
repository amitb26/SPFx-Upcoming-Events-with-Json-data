import * as React from 'react';
import { useState, useEffect } from 'react';
//import styles from './UPennEventCal.module.scss';
import { IUPennEventCalProps } from './IUPennEventCalProps';
import styles from './UPennEventCal.module.scss';

interface IEvent {
    id:string;
    title: string;
    date: string;
    description: string;
    start_date: string;
    end_date: string;
    image: {
        url:string
    }
    venue: {
      venue: string;
      address:string;
      city:string;
      state:string;
      zip:string;
      country:string
    }
    url:string;
}

const EventCalendar: React.FC<IUPennEventCalProps> = ({ title, jsonUrl, maxEvents }) => {
  const [events, setEvents] = useState<IEvent[]>([]);
  const displayMaxEvents = maxEvents ? maxEvents : "14";
  useEffect(() => {
    if (jsonUrl) {
      fetch(jsonUrl)
        .then(response => response.json())
        .then(data => {
          const today = new Date();
          const fourteenDaysLater = new Date();
          fourteenDaysLater.setDate(today.getDate() + parseInt(displayMaxEvents));

          // Filter events occurring within the next 14 days
          const filteredEvents = data.events.filter((event: IEvent) => {
            const eventDate = new Date(event.start_date);
            return eventDate.toLocaleDateString() >= today.toLocaleDateString() && eventDate.toLocaleDateString() <= fourteenDaysLater.toLocaleDateString();
          });

          setEvents(filteredEvents);
        }) // Limit events based on maxEvents
        .catch(error => console.error("Error fetching events:", error));
    }
  }, [jsonUrl, maxEvents]);

  const sanitizeText = (text: string) => {
    return text
    .replace(/&amp;/g, '&')         // Replace all instances of "&amp;" with "&"
    .replace(/&#\d+;/g, '-'); 
  };

  const formatVenue = (location: IEvent['venue']): string => {
    const { venue, address, city, state, zip, country } = location;
    // Build an array of non-empty parts
  const parts = [
    venue && venue.trim(),
    address && address.trim(),
    city && city.trim(), // Include only if `city` exists and is not blank
    state && state.trim(),
    zip && zip.trim(),
    country && country.trim(),   // Include only if `zip` exists and is not blank
  ].filter(Boolean);      // Filter out empty values
  
  return parts.join(', '); // Join the parts with a comma and space
  };

  return (
    <div className={styles['upcoming-events-container']}>
      <h2 className={styles['events-title']}>{title || 'Upcoming Events'}</h2>
      <div className={styles['events-list']}>
        {events.map(event => {
          //const eventVenue = event.venue.venue
          const eventDate = new Date(event.start_date);
          const startDate = new Date(event.start_date);
          const endDate = new Date(event.end_date);
          const day = eventDate.toLocaleString('en-US', { day: 'numeric' });
          const month = eventDate.toLocaleString('en-US', { month: 'short' });
          const formattedStartTime = startDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
          const formattedEndTime = endDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });

          return (
            <div className={styles['event-card']} key={event.id}>
              <div className={styles['event-date']}>
                <div className={styles['event-day']}>{day}</div>
                <div className={styles['event-month']}>{month}</div>
              </div>
              <div className={styles['event-details']}>
                <div className={styles['event-info']}>
                <h3 className={styles['event-title']}>
                <a href={event.url} target="_blank" rel="noopener noreferrer">
                {sanitizeText(event.title)}
                  </a>
                  </h3>
                  <p className={styles['event-location']}>Venue: {sanitizeText(formatVenue(event.venue))}</p>
                  <p className={styles['event-dates']}>
                    {formattedStartTime} - {formattedEndTime}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>

 );
};

export default EventCalendar;
