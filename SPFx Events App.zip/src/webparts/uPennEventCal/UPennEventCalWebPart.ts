//import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import * as React from 'react';
import * as ReactDom from 'react-dom';
import UpcomingEvents from './components/UPennEventCal';
import { IUPennEventCalProps } from './components/IUPennEventCalProps';

export interface IUpcomingEventsWebPartProps {
  title: string;
  jsonUrl: string;
  maxEvents: string;
}

export default class UpcomingEventsWebPart extends BaseClientSideWebPart<IUpcomingEventsWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IUPennEventCalProps> = React.createElement(
      UpcomingEvents,
      {
        title: this.properties.title,
        jsonUrl: this.properties.jsonUrl,
        maxEvents: this.properties.maxEvents,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: { description: "Upcoming Events Settings" },
          groups: [
            {
              groupName: "Basic Settings",
              groupFields: [
                PropertyPaneTextField('title', {
                  label: "Web Part Title",
                  placeholder: "Enter a title for the web part"
                }),
                PropertyPaneTextField('jsonUrl', {
                  label: "Events JSON URL",
                  placeholder: "Enter the URL to your events JSON file"
                }),
                PropertyPaneTextField('maxEvents', {
                  label: "Maximum Number of Days to Display",
                  placeholder: "Enter Number of Days"
                  
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
