define("92595c54-7cef-4a38-ae9b-a648c8563ef8_0.0.1", ["@microsoft/sp-property-pane","@microsoft/sp-webpart-base","react","react-dom"], (__WEBPACK_EXTERNAL_MODULE__723__, __WEBPACK_EXTERNAL_MODULE__134__, __WEBPACK_EXTERNAL_MODULE__650__, __WEBPACK_EXTERNAL_MODULE__729__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 360:
/*!************************************************************************!*\
  !*** ./lib/webparts/uPennEventCal/components/UPennEventCal.module.css ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 726);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".upcoming-events-container_911533f2{margin:0 auto;max-width:900px;padding:20px}.events-title_911533f2{font-size:24px;margin-bottom:30px;text-align:left}.events-list_911533f2{display:flex;flex-direction:column;gap:20px}.event-card_911533f2{align-items:center;background-color:#f4f4f4;border-radius:8px;box-shadow:0 4px 8px rgba(0,0,0,.1);display:flex;padding:15px;transition:box-shadow .3s}.event-card_911533f2:hover{box-shadow:0 8px 16px rgba(0,0,0,.2)}.event-date_911533f2{align-items:center;background-color:#011f5b;border-radius:8px;color:#fff;display:flex;flex-direction:column;height:60px;justify-content:center;margin-right:20px;padding:10px;text-align:center;width:60px}.event-day_911533f2{font-size:18px;font-weight:700}.event-month_911533f2{font-size:14px;text-transform:uppercase}.event-details_911533f2{align-items:center;display:flex;flex:1}.event-image_911533f2{border-radius:8px;height:100px;margin-right:20px;object-fit:cover;width:100px}.event-info_911533f2{flex:1}.event-title_911533f2{font-size:15px;font-weight:700;margin:0}.event-location_911533f2{color:#666;font-size:14px;font-style:italic;margin:5px 0}.event-description_911533f2{-webkit-box-orient:vertical;color:#333;display:-webkit-box;font-size:14px;overflow:hidden;text-overflow:ellipsis}.event-dates_911533f2{color:#555;font-size:14px;font-style:italic;margin:5px 0}.event-title_911533f2 a{color:#464748;text-decoration:none}.event-title_911533f2 a:hover{text-decoration:underline}.uPennEventCal_911533f2{color:\"[theme:bodyText, default: #323130]\";color:var(--bodyText);overflow:hidden;padding:1em}.uPennEventCal_911533f2.teams_911533f2{font-family:Segoe UI,-apple-system,BlinkMacSystemFont,Roboto,Helvetica Neue,sans-serif}.welcome_911533f2{text-align:center}.welcomeImage_911533f2{max-width:420px;width:100%}.links_911533f2 a{color:\"[theme:link, default:#03787c]\";color:var(--link);text-decoration:none}.links_911533f2 a:hover{color:\"[theme:linkHovered, default: #014446]\";color:var(--linkHovered);text-decoration:underline}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvYXNoYXJtYS9FdmVudENhbGVuZGFyL3NyYy93ZWJwYXJ0cy91UGVubkV2ZW50Q2FsL2NvbXBvbmVudHMvVVBlbm5FdmVudENhbC5tb2R1bGUuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQSxvQ0FFRSxhQUFBLENBREEsZUFBQSxDQUVBLFlBQUEsQ0FHRix1QkFFRSxjQUFBLENBQ0Esa0JBQUEsQ0FGQSxlQUVBLENBSUYsc0JBQ0UsWUFBQSxDQUNBLHFCQUFBLENBQ0EsUUFBQSxDQUdGLHFCQUVFLGtCQUFBLENBRUEsd0JBQUEsQ0FDQSxpQkFBQSxDQUNBLG1DQUFBLENBTEEsWUFBQSxDQUVBLFlBQUEsQ0FJQSx5QkFBQSxDQUdGLDJCQUNFLG9DQUFBLENBSUYscUJBR0Usa0JBQUEsQ0FFQSx3QkFBQSxDQUtBLGlCQUFBLENBSkEsVUFBQSxDQUxBLFlBQUEsQ0FDQSxxQkFBQSxDQU9BLFdBQUEsQ0FMQSxzQkFBQSxDQU9BLGlCQUFBLENBSkEsWUFBQSxDQUtBLGlCQUFBLENBSkEsVUFJQSxDQUdGLG9CQUNFLGNBQUEsQ0FDQSxlQUFBLENBR0Ysc0JBQ0UsY0FBQSxDQUNBLHdCQUFBLENBSUYsd0JBRUUsa0JBQUEsQ0FEQSxZQUFBLENBRUEsTUFBQSxDQUdGLHNCQUdFLGlCQUFBLENBREEsWUFBQSxDQUdBLGlCQUFBLENBREEsZ0JBQUEsQ0FIQSxXQUlBLENBR0YscUJBQ0UsTUFBQSxDQUdGLHNCQUNFLGNBQUEsQ0FDQSxlQUFBLENBQ0EsUUFBQSxDQUdGLHlCQUVFLFVBQUEsQ0FEQSxjQUFBLENBR0EsaUJBQUEsQ0FEQSxZQUNBLENBR0YsNEJBT0UsMkJBQUEsQ0FMQSxVQUFBLENBR0EsbUJBQUEsQ0FKQSxjQUFBLENBRUEsZUFBQSxDQUNBLHNCQUdBLENBRUYsc0JBRUUsVUFBQSxDQURBLGNBQUEsQ0FHQSxpQkFBQSxDQURBLFlBQ0EsQ0FFRix3QkFDRSxhQUFBLENBQ0Esb0JBQUEsQ0FHRiw4QkFDRSx5QkFBQSxDQUtGLHdCQUdFLDBDQUFBLENBQ0EscUJBQUEsQ0FIQSxlQUFBLENBQ0EsV0FFQSxDQUNBLHVDQUNFLHNGQUFBLENBSUosa0JBQ0UsaUJBQUEsQ0FHRix1QkFFRSxlQUFBLENBREEsVUFDQSxDQUlBLGtCQUVFLHFDQUFBLENBQ0EsaUJBQUEsQ0FGQSxvQkFFQSxDQUVBLHdCQUVFLDZDQUFBLENBQ0Esd0JBQUEsQ0FGQSx5QkFFQSIsImZpbGUiOiJVUGVubkV2ZW50Q2FsLm1vZHVsZS5jc3MifQ== */", true);


/***/ }),

/***/ 891:
/*!****************************************************************!*\
  !*** ./lib/webparts/uPennEventCal/components/UPennEventCal.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UPennEventCal.module.scss */ 79);



var EventCalendar = function (_a) {
    var title = _a.title, jsonUrl = _a.jsonUrl, maxEvents = _a.maxEvents;
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), events = _b[0], setEvents = _b[1];
    var displayMaxEvents = maxEvents ? maxEvents : "14";
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        if (jsonUrl) {
            fetch(jsonUrl)
                .then(function (response) { return response.json(); })
                .then(function (data) {
                var today = new Date();
                var fourteenDaysLater = new Date();
                fourteenDaysLater.setDate(today.getDate() + parseInt(displayMaxEvents));
                // Filter events occurring within the next 14 days
                var filteredEvents = data.events.filter(function (event) {
                    var eventDate = new Date(event.start_date);
                    return eventDate.toLocaleDateString() >= today.toLocaleDateString() && eventDate.toLocaleDateString() <= fourteenDaysLater.toLocaleDateString();
                });
                setEvents(filteredEvents);
            }) // Limit events based on maxEvents
                .catch(function (error) { return console.error("Error fetching events:", error); });
        }
    }, [jsonUrl, maxEvents]);
    var sanitizeText = function (text) {
        return text
            .replace(/&amp;/g, '&') // Replace all instances of "&amp;" with "&"
            .replace(/&#\d+;/g, '-');
    };
    var formatVenue = function (location) {
        var venue = location.venue, address = location.address, city = location.city, state = location.state, zip = location.zip, country = location.country;
        // Build an array of non-empty parts
        var parts = [
            venue && venue.trim(),
            address && address.trim(),
            city && city.trim(),
            state && state.trim(),
            zip && zip.trim(),
            country && country.trim(), // Include only if `zip` exists and is not blank
        ].filter(Boolean); // Filter out empty values
        return parts.join(', '); // Join the parts with a comma and space
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['upcoming-events-container'] },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['events-title'] }, title || 'Upcoming Events'),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['events-list'] }, events.map(function (event) {
            //const eventVenue = event.venue.venue
            var eventDate = new Date(event.start_date);
            var startDate = new Date(event.start_date);
            var endDate = new Date(event.end_date);
            var day = eventDate.toLocaleString('en-US', { day: 'numeric' });
            var month = eventDate.toLocaleString('en-US', { month: 'short' });
            var formattedStartTime = startDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
            var formattedEndTime = endDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-card'], key: event.id },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-date'] },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-day'] }, day),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-month'] }, month)),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-details'] },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-info'] },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-title'] },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: event.url, target: "_blank", rel: "noopener noreferrer" }, sanitizeText(event.title))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-location'] },
                            "Venue: ",
                            sanitizeText(formatVenue(event.venue))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: _UPennEventCal_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['event-dates'] },
                            formattedStartTime,
                            " - ",
                            formattedEndTime)))));
        }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EventCalendar);


/***/ }),

/***/ 79:
/*!****************************************************************************!*\
  !*** ./lib/webparts/uPennEventCal/components/UPennEventCal.module.scss.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
__webpack_require__(/*! ./UPennEventCal.module.css */ 360);
var styles = {
    'upcoming-events-container': 'upcoming-events-container_911533f2',
    'events-title': 'events-title_911533f2',
    'events-list': 'events-list_911533f2',
    'event-card': 'event-card_911533f2',
    'event-date': 'event-date_911533f2',
    'event-day': 'event-day_911533f2',
    'event-month': 'event-month_911533f2',
    'event-details': 'event-details_911533f2',
    'event-image': 'event-image_911533f2',
    'event-info': 'event-info_911533f2',
    'event-title': 'event-title_911533f2',
    'event-location': 'event-location_911533f2',
    'event-description': 'event-description_911533f2',
    'event-dates': 'event-dates_911533f2',
    uPennEventCal: 'uPennEventCal_911533f2',
    teams: 'teams_911533f2',
    welcome: 'welcome_911533f2',
    welcomeImage: 'welcomeImage_911533f2',
    links: 'links_911533f2'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);


/***/ }),

/***/ 726:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadStyles: () => (/* binding */ loadStyles)
/* harmony export */ });
/* unused harmony exports Mode, ClearStyleOptions, configureLoadStyles, configureRunMode, flush, loadTheme, clearStyles, detokenize, splitStyles */
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/**
 * In sync mode, styles are registered as style elements synchronously with loadStyles() call.
 * In async mode, styles are buffered and registered as batch in async timer for performance purpose.
 */
var Mode;
(function (Mode) {
    Mode[Mode["sync"] = 0] = "sync";
    Mode[Mode["async"] = 1] = "async";
})(Mode || (Mode = {}));
/**
 * Themable styles and non-themable styles are tracked separately
 * Specify ClearStyleOptions when calling clearStyles API to specify which group of registered styles should be cleared.
 */
var ClearStyleOptions;
(function (ClearStyleOptions) {
    /** only themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyThemable"] = 1] = "onlyThemable";
    /** only non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyNonThemable"] = 2] = "onlyNonThemable";
    /** both themable and non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["all"] = 3] = "all";
})(ClearStyleOptions || (ClearStyleOptions = {}));
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? __webpack_require__.g : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: Mode.sync,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === Mode.async) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    // Use "self" to distinguish conflicting global typings for setTimeout() from lib.dom.d.ts vs Jest's @types/node
    // https://github.com/jestjs/jest/issues/14418
    return self.setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = ClearStyleOptions.all; }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyNonThemable) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyThemable) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(ClearStyleOptions.onlyThemable);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                // eslint-disable-next-line no-console
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}


/***/ }),

/***/ 723:
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__723__;

/***/ }),

/***/ 134:
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__134__;

/***/ }),

/***/ 650:
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__650__;

/***/ }),

/***/ 729:
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__729__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!************************************************************!*\
  !*** ./lib/webparts/uPennEventCal/UPennEventCalWebPart.js ***!
  \************************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/sp-property-pane */ 723);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ 134);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ 650);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-dom */ 729);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_UPennEventCal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/UPennEventCal */ 891);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//import { Version } from '@microsoft/sp-core-library';





var UpcomingEventsWebPart = /** @class */ (function (_super) {
    __extends(UpcomingEventsWebPart, _super);
    function UpcomingEventsWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    UpcomingEventsWebPart.prototype.render = function () {
        var element = react__WEBPACK_IMPORTED_MODULE_2__.createElement(_components_UPennEventCal__WEBPACK_IMPORTED_MODULE_4__["default"], {
            title: this.properties.title,
            jsonUrl: this.properties.jsonUrl,
            maxEvents: this.properties.maxEvents,
        });
        react_dom__WEBPACK_IMPORTED_MODULE_3__.render(element, this.domElement);
    };
    UpcomingEventsWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_3__.unmountComponentAtNode(this.domElement);
    };
    UpcomingEventsWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: { description: "Upcoming Events Settings" },
                    groups: [
                        {
                            groupName: "Basic Settings",
                            groupFields: [
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__.PropertyPaneTextField)('title', {
                                    label: "Web Part Title",
                                    placeholder: "Enter a title for the web part"
                                }),
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__.PropertyPaneTextField)('jsonUrl', {
                                    label: "Events JSON URL",
                                    placeholder: "Enter the URL to your events JSON file"
                                }),
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_0__.PropertyPaneTextField)('maxEvents', {
                                    label: "Maximum Number of Days to Display",
                                    placeholder: "Enter Number of Days"
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return UpcomingEventsWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_1__.BaseClientSideWebPart));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UpcomingEventsWebPart);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});;
//# sourceMappingURL=u-penn-event-cal-web-part.js.map