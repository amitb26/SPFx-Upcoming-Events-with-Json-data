declare const styles: {
    'upcoming-events-container': string;
    'events-title': string;
    'events-list': string;
    'event-card': string;
    'event-date': string;
    'event-day': string;
    'event-month': string;
    'event-details': string;
    'event-image': string;
    'event-info': string;
    'event-title': string;
    'event-location': string;
    'event-description': string;
    'event-dates': string;
    uPennEventCal: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=UPennEventCal.module.scss.d.ts.map