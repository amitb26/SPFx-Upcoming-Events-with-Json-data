export interface IUPennEventCalProps {
    title: string;
    jsonUrl: string;
    maxEvents: string;
}
//# sourceMappingURL=IUPennEventCalProps.d.ts.map