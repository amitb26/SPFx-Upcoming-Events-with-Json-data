import * as React from 'react';
import { IUPennEventCalProps } from './IUPennEventCalProps';
declare const EventCalendar: React.FC<IUPennEventCalProps>;
export default EventCalendar;
//# sourceMappingURL=Event.d.ts.map